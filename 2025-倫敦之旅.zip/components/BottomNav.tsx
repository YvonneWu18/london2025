import React from 'react';
import { Home, Calendar, List, Sparkles, Briefcase } from './Icons';

interface BottomNavProps {
  currentTab: string;
  setTab: (tab: string) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ currentTab, setTab }) => {
  const navItems = [
    { id: 'home', label: '首頁', icon: Home },
    { id: 'schedule', label: '行程', icon: Calendar },
    { id: 'packing', label: '清單', icon: Briefcase },
    { id: 'backup', label: '備案', icon: List },
    { id: 'assistant', label: '助理', icon: Sparkles },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-xl border-t border-slate-200 pb-safe pt-2 px-4 shadow-2xl z-50">
      <div className="flex justify-between items-center max-w-md mx-auto h-16 pb-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setTab(item.id)}
              className={`flex flex-col items-center justify-center space-y-1 w-14 transition-all duration-300 ${
                isActive ? 'text-[#CF142B] -translate-y-1' : 'text-slate-400 hover:text-slate-600'
              }`}
            >
              <Icon className={`w-6 h-6 ${isActive ? 'fill-current' : ''}`} strokeWidth={isActive ? 2.5 : 2} />
              <span className={`text-[10px] font-bold ${isActive ? 'opacity-100' : 'opacity-80'}`}>{item.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};