import React, { useState } from 'react';
import { ItineraryItem } from '../types';
import { ActivityIcon, Navigation, GripVertical, Trash2, Clock, Ticket, List, Edit } from './Icons';

interface ItineraryCardProps {
  item: ItineraryItem;
  index: number;
  onDragStart: (e: React.DragEvent, index: number) => void;
  onDragEnter: (e: React.DragEvent, index: number) => void;
  onDragEnd: (e: React.DragEvent) => void;
  onDelete: () => void;
  onEdit: () => void;
  onUpdateDuration: (newDuration: number) => void;
  isDragging: boolean;
}

export const ItineraryCard: React.FC<ItineraryCardProps> = ({ 
  item, 
  index,
  onDragStart,
  onDragEnter,
  onDragEnd,
  onDelete,
  onEdit,
  onUpdateDuration,
  isDragging 
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const handleDurationChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onUpdateDuration(parseInt(e.target.value));
  };

  const getTypeColor = (type: string) => {
    switch(type) {
        // Keeping semantic colors but slightly desaturated to match the elegant London theme
        case 'Flight': return 'bg-sky-50 text-sky-700';
        case 'Food': return 'bg-orange-50 text-orange-700';
        case 'Shopping': return 'bg-rose-50 text-rose-700';
        case 'Hotel': return 'bg-indigo-50 text-indigo-700';
        case 'Sightseeing': return 'bg-emerald-50 text-emerald-700';
        case 'Event': return 'bg-purple-50 text-purple-700';
        case 'Transport': return 'bg-slate-100 text-slate-600';
        default: return 'bg-slate-50 text-slate-600';
    }
  };

  const getGoogleMapsUrl = () => {
    // 優先使用經緯度，這是最精確的導航方式
    if (item.coordinates) {
      return `https://www.google.com/maps/dir/?api=1&destination=${item.coordinates.lat},${item.coordinates.lng}`;
    }
    // 如果只有名稱，加上 "London, UK" 以確保定位到倫敦的正確地點
    // 使用 /dir/ 確保開啟路線規劃功能，而非僅顯示地點
    const destinationQuery = `${item.locationName}, London, UK`;
    return `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(destinationQuery)}`;
  };

  return (
    <div 
      className={`relative pl-6 pb-8 border-l-[3px] last:border-l-0 last:pb-0 group transition-all duration-300 
        ${isDragging ? 'opacity-40 scale-95 border-slate-200' : 'opacity-100 border-[#00247D]/10'}
      `}
      onDragEnter={(e) => onDragEnter(e, index)}
      onDragOver={(e) => e.preventDefault()}
    >
      {/* Timeline Dot with London Blue */}
      <div className="absolute -left-[11px] top-0 w-[22px] h-[22px] rounded-full bg-white border-[5px] border-[#00247D] shadow-sm z-10 group-hover:scale-110 group-hover:border-[#CF142B] transition-all duration-300"></div>

      <div 
        draggable
        onDragStart={(e) => onDragStart(e, index)}
        onDragEnd={onDragEnd}
        className={`
          w-full bg-white rounded-2xl p-6 relative cursor-pointer
          border transition-all duration-300 ease-out
          ${isExpanded 
            ? 'ring-2 ring-[#00247D]/10 shadow-lg border-[#00247D]/30' 
            : 'shadow-[0_2px_8px_-2px_rgba(0,0,0,0.05)] border-slate-200 hover:shadow-md hover:border-[#00247D]/30'
          }
        `}
        onClick={() => setIsExpanded(!isExpanded)}
      >
        {/* Drag Handle */}
        <div className="absolute right-3 top-5 text-slate-300 cursor-grab active:cursor-grabbing p-1 hover:text-[#00247D] transition-colors z-20">
           <GripVertical className="w-5 h-5" />
        </div>

        {/* Main Content Layout - Flex for responsive alignment */}
        <div className="flex items-start gap-5 pr-6">
           {/* Icon Box */}
           <div className={`p-3.5 rounded-2xl flex-shrink-0 shadow-sm transition-transform duration-300 group-hover:scale-105 ${getTypeColor(item.type)}`}>
             <ActivityIcon type={item.type} className="w-6 h-6" />
           </div>
           
           {/* Text Content */}
           <div className="flex-1 min-w-0 py-0.5">
             {/* Header Row: Time & Duration */}
             <div className="flex flex-wrap items-center gap-3 mb-2.5">
               {/* Updated Time Display: High contrast badge */}
               <div className="bg-[#00247D] text-white px-3 py-1.5 rounded-lg shadow-sm border border-blue-900 flex items-center justify-center">
                 <span className="font-mono text-lg font-bold tracking-wider leading-none">
                   {item.time}
                 </span>
               </div>
               
               {/* Updated Duration Display: Subtle style */}
               <div className="flex items-center space-x-1.5 px-2.5 py-1 rounded-full bg-slate-50 border border-slate-200">
                 <Clock className="w-3.5 h-3.5 text-slate-400" />
                 <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">
                    {item.duration} min
                 </span>
               </div>
             </div>
             
             {/* Title & Description */}
             <h4 className="font-display font-bold text-slate-900 text-xl leading-snug mb-2 truncate pr-4 group-hover:text-[#00247D] transition-colors tracking-tight">
               {item.title}
             </h4>
             <p className="text-sm text-slate-600 line-clamp-2 leading-relaxed mb-3 font-medium">
               {item.description}
             </p>
             
             {/* Location Link */}
             {item.locationName && (
               <a
                 href={getGoogleMapsUrl()}
                 target="_blank"
                 rel="noopener noreferrer"
                 onClick={(e) => e.stopPropagation()}
                 className="inline-flex items-center text-xs font-bold text-slate-400 uppercase tracking-widest transition-all hover:text-[#CF142B] hover:underline decoration-2 underline-offset-2"
                 title="開啟 Google Maps 導航"
               >
                 <Navigation className="w-3.5 h-3.5 mr-1.5" />
                 <span className="truncate max-w-[200px]">{item.locationName}</span>
               </a>
             )}
           </div>
        </div>

        {/* Expanded Controls - Animated */}
        {isExpanded && (
          <div className="mt-6 pt-6 border-t border-slate-100 animate-fade-in cursor-default" onClick={(e) => e.stopPropagation()}>
            <div className="space-y-5">
              
              {/* Details Section: Price & Notes */}
              {(item.notes || item.price) && (
                <div className="grid grid-cols-1 gap-3">
                   {item.price && (
                     <div className="flex items-center gap-3 text-sm text-slate-700 bg-[#F5F5F7] p-3.5 rounded-xl border border-slate-200">
                       <div className="bg-white p-1.5 rounded-lg shadow-sm text-emerald-600">
                         <Ticket className="w-4 h-4" />
                       </div>
                       <div className="flex flex-col">
                         <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">預算 / 門票</span>
                         <span className="font-bold text-slate-800">{item.price}</span>
                       </div>
                     </div>
                   )}
                   
                   {item.notes && (
                     <div className="flex items-start gap-3 text-sm text-slate-700 bg-[#FFF9F0] p-3.5 rounded-xl border border-orange-100">
                       <div className="bg-white p-1.5 rounded-lg shadow-sm mt-0.5 text-orange-500">
                         <List className="w-4 h-4" />
                       </div>
                       <div className="flex-1">
                         <span className="text-[10px] font-bold text-orange-400 uppercase tracking-wider block mb-1">筆記</span>
                         <span className="whitespace-pre-wrap text-slate-700 leading-relaxed block font-medium">{item.notes}</span>
                       </div>
                     </div>
                   )}
                </div>
              )}

              {/* Duration Slider Control */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 group/slider hover:border-[#00247D]/20 transition-colors">
                <div className="flex justify-between text-xs font-bold text-slate-500 mb-3">
                  <span className="flex items-center text-[#00247D]">
                    <Clock className="w-3.5 h-3.5 mr-1.5"/> 
                    調整停留時間
                  </span>
                  <span className="text-[#00247D] bg-white px-2 py-0.5 rounded shadow-sm border border-slate-100">
                    {item.duration} 分鐘
                  </span>
                </div>
                <input 
                  type="range" 
                  min="30" 
                  max="360" 
                  step="15" 
                  value={item.duration || 60} 
                  onChange={handleDurationChange}
                  className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-[#00247D] hover:accent-[#CF142B] transition-all"
                />
                <div className="flex justify-between text-[10px] text-slate-400 mt-2 font-medium uppercase tracking-wider">
                  <span>30m</span>
                  <span>6h</span>
                </div>
              </div>

              {/* Actions */}
              <div className="flex justify-end pt-2 gap-3">
                 <button 
                   onClick={(e) => {
                     e.stopPropagation();
                     onEdit();
                   }}
                   className="flex-1 md:flex-none flex items-center justify-center space-x-2 text-[#00247D] bg-blue-50 hover:bg-blue-100 px-5 py-2.5 rounded-xl transition-all text-xs font-bold border border-blue-100 shadow-sm"
                 >
                   <Edit className="w-4 h-4" />
                   <span>編輯資訊</span>
                 </button>
                 <button 
                   onClick={(e) => {
                     e.stopPropagation();
                     onDelete();
                   }}
                   className="flex-1 md:flex-none flex items-center justify-center space-x-2 text-[#CF142B] bg-white hover:bg-[#CF142B]/5 px-5 py-2.5 rounded-xl transition-all text-xs font-bold border border-slate-200 hover:border-[#CF142B]/30 shadow-sm"
                 >
                   <Trash2 className="w-4 h-4" />
                   <span>刪除</span>
                 </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};