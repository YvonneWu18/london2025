import React, { useEffect, useState } from 'react';
import { CloudRain } from './Icons';
import { getWeatherAdvice } from '../services/geminiService';

interface WeatherWidgetProps {
  date: string;
}

export const WeatherWidget: React.FC<WeatherWidgetProps> = ({ date }) => {
  const [advice, setAdvice] = useState<string>("正在載入天氣預報...");

  useEffect(() => {
    let isMounted = true;
    getWeatherAdvice(date).then(res => {
      if (isMounted) setAdvice(res);
    });
    return () => { isMounted = false; };
  }, [date]);

  return (
    <div className="bg-gradient-to-br from-[#00247D] to-[#001955] rounded-2xl p-5 text-white shadow-xl shadow-blue-900/10 mb-8 border border-white/10 relative overflow-hidden">
      <div className="absolute top-0 right-0 p-4 opacity-10">
         <CloudRain className="w-24 h-24 text-white" />
      </div>
      <div className="flex items-start space-x-4 relative z-10">
        <div className="p-3 bg-white/10 rounded-xl backdrop-blur-md shadow-inner">
          <CloudRain className="w-6 h-6 text-white" />
        </div>
        <div>
          <h3 className="font-bold text-xs tracking-[0.2em] opacity-80 mb-2 font-mono uppercase text-blue-200">{date} 倫敦天氣</h3>
          <p className="text-sm font-medium leading-relaxed opacity-95 pr-8 tracking-wide">{advice}</p>
        </div>
      </div>
    </div>
  );
};