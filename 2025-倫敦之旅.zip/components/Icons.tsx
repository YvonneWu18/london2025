import React from 'react';
import { 
  Plane, 
  Hotel, 
  Utensils, 
  Camera, 
  Train, 
  ShoppingBag, 
  Ticket, 
  MapPin, 
  Umbrella, 
  Calendar, 
  Home, 
  List, 
  Sparkles,
  Navigation,
  CloudRain,
  Plus,
  Trash2,
  CheckCircle,
  Circle,
  X,
  Link,
  Briefcase,
  GripVertical,
  Clock,
  Map as MapIcon,
  Edit
} from 'lucide-react';
import { ActivityType } from '../types';

export const ActivityIcon = ({ type, className }: { type: ActivityType; className?: string }) => {
  const props = { className: className || "w-5 h-5" };
  switch (type) {
    case ActivityType.FLIGHT: return <Plane {...props} />;
    case ActivityType.HOTEL: return <Hotel {...props} />;
    case ActivityType.FOOD: return <Utensils {...props} />;
    case ActivityType.SIGHTSEEING: return <Camera {...props} />;
    case ActivityType.TRANSPORT: return <Train {...props} />;
    case ActivityType.SHOPPING: return <ShoppingBag {...props} />;
    case ActivityType.EVENT: return <Ticket {...props} />;
    default: return <MapPin {...props} />;
  }
};

export { 
  MapPin, 
  Umbrella, 
  Calendar, 
  Home, 
  List, 
  Sparkles, 
  Navigation,
  CloudRain,
  Plus,
  Trash2,
  CheckCircle,
  Circle,
  X,
  Link,
  Briefcase,
  GripVertical,
  Clock,
  MapIcon,
  Ticket,
  Edit
};