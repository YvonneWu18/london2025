import React, { useEffect, useRef } from 'react';
import L from 'leaflet';
import { ItineraryItem } from '../types';

interface MapViewProps {
  items: ItineraryItem[];
}

export const MapView: React.FC<MapViewProps> = ({ items }) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersRef = useRef<L.Marker[]>([]);
  const polylineRef = useRef<L.Polyline | null>(null);

  useEffect(() => {
    if (!mapContainerRef.current) return;

    // Initialize map if not already initialized
    if (!mapInstanceRef.current) {
      mapInstanceRef.current = L.map(mapContainerRef.current, {
        zoomControl: false,
        attributionControl: false
      }).setView([51.505, -0.09], 13);

      L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
        subdomains: 'abcd',
        maxZoom: 20
      }).addTo(mapInstanceRef.current);
    }

    const map = mapInstanceRef.current;

    // Clear existing markers
    markersRef.current.forEach(marker => marker.remove());
    markersRef.current = [];
    if (polylineRef.current) {
      polylineRef.current.remove();
      polylineRef.current = null;
    }

    // Filter items with coordinates
    const validItems = items.filter(item => item.coordinates);
    const latLngs: L.LatLngExpression[] = [];

    // Create custom icon function
    const createCustomIcon = (index: number, type: string) => {
      const color = type === 'Food' ? '#ea580c' : type === 'Shopping' ? '#db2777' : '#00247D';
      
      return L.divIcon({
        className: 'custom-div-icon',
        html: `
          <div style="
            background-color: ${color};
            width: 24px;
            height: 24px;
            border-radius: 50%;
            border: 2px solid white;
            box-shadow: 0 2px 4px rgba(0,0,0,0.3);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 12px;
            font-weight: bold;
            font-family: sans-serif;
          ">${index + 1}</div>
          <div style="
            position: absolute;
            bottom: -6px;
            left: 50%;
            transform: translateX(-50%);
            width: 0; 
            height: 0; 
            border-left: 6px solid transparent;
            border-right: 6px solid transparent;
            border-top: 6px solid ${color};
          "></div>
        `,
        iconSize: [24, 30],
        iconAnchor: [12, 30],
        popupAnchor: [0, -32]
      });
    };

    validItems.forEach((item, index) => {
      if (item.coordinates) {
        const { lat, lng } = item.coordinates;
        latLngs.push([lat, lng]);

        const marker = L.marker([lat, lng], {
          icon: createCustomIcon(index, item.type)
        })
          .bindPopup(`
            <div style="font-family: sans-serif; padding: 4px;">
              <div style="font-weight: bold; color: #00247D; margin-bottom: 2px;">${item.time}</div>
              <div style="font-weight: bold; font-size: 14px; margin-bottom: 4px;">${item.title}</div>
              <div style="font-size: 12px; color: #64748b; margin-bottom: 8px;">${item.locationName}</div>
              <a href="https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}" target="_blank" style="
                display: block;
                background-color: #00247D;
                color: white;
                text-align: center;
                padding: 6px;
                border-radius: 6px;
                text-decoration: none;
                font-size: 11px;
                font-weight: bold;
              ">Google Maps 路線</a>
            </div>
          `)
          .addTo(map);

        markersRef.current.push(marker);
      }
    });

    // Draw polyline connecting the dots
    if (latLngs.length > 1) {
      polylineRef.current = L.polyline(latLngs, {
        color: '#00247D',
        weight: 3,
        opacity: 0.6,
        dashArray: '5, 10',
        lineCap: 'round'
      }).addTo(map);
    }

    // Fit bounds
    if (latLngs.length > 0) {
      map.fitBounds(L.latLngBounds(latLngs), { padding: [50, 50] });
    } else {
      // Default to London center if no points
      map.setView([51.505, -0.09], 13);
    }

  }, [items]);

  return (
    <div className="w-full h-[60vh] rounded-2xl overflow-hidden shadow-inner border border-slate-200 bg-slate-100 relative z-0">
      <div ref={mapContainerRef} className="w-full h-full" />
    </div>
  );
};