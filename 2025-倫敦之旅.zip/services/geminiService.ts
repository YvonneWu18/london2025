import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
const modelId = "gemini-2.5-flash";

export const getWeatherAdvice = async (date: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: modelId,
      contents: `為 2025 年 12 月 ${date} 在倫敦的旅客提供非常簡短的天氣預測和穿著建議（繁體中文）。重點關注可能的溫度、降雨機率以及穿著建議（例如：雨傘、厚外套）。最多 50 個字。`,
    });
    return response.text || "預期會有寒冷的天氣和降雨。請攜帶保暖外套和雨傘。";
  } catch (error) {
    console.error("Gemini Weather Error:", error);
    return "倫敦 12 月通常寒冷 (4-9°C) 且多雨。請穿著多層次衣物並攜帶雨傘。";
  }
};

export const getAlternativePlans = async (context: string): Promise<any> => {
  try {
    const response = await ai.models.generateContent({
      model: modelId,
      contents: `我是一名 2025 年 12 月在倫敦的遊客。我目前的計畫是「${context}」。
      請建議 3 個附近的具體室內替代活動，以防大雨或景點關閉。
      請嚴格返回具有此架構的 JSON 物件（內容請使用繁體中文）：
      {
        "suggestions": [
           { "title": "活動名稱", "description": "簡短描述", "location": "地址或區域" }
        ]
      }`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            suggestions: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  description: { type: Type.STRING },
                  location: { type: Type.STRING }
                }
              }
            }
          }
        }
      }
    });

    const text = response.text;
    if (!text) return { suggestions: [] };
    return JSON.parse(text);
  } catch (error) {
    console.error("Gemini Plan Error:", error);
    return { suggestions: [] };
  }
};

export const analyzeItineraryInput = async (input: string, dateLabel: string): Promise<any> => {
  try {
    const response = await ai.models.generateContent({
      model: modelId,
      contents: `使用者提供了一個旅遊地點的連結或描述： "${input}"。
      這是在倫敦行程的 ${dateLabel}。
      請分析這個輸入，並產生一個 JSON 物件，包含行程項目的詳細資訊。
      
      請包含以下資訊：
      1. title: 地點或活動名稱 (繁體中文)
      2. description: 簡短描述活動內容，並包含建議的「交通方式」(例如：最近的地鐵站或如何從市中心前往) (繁體中文)
      3. time: 建議的開始時間 (格式如 14:00)，請根據活動性質猜測。
      4. type: 活動類型 (只能是其中之一: Sightseeing, Food, Shopping, Event, Transport, Hotel)
      5. locationName: 地點英文名稱 (用於地圖搜尋)
      6. lat/lng: 該地點在倫敦的大致經緯度 (latitude, longitude)
      7. duration: 建議的停留時間，以分鐘為單位 (number)。
      
      請嚴格返回 JSON 格式。`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            description: { type: Type.STRING },
            time: { type: Type.STRING },
            type: { type: Type.STRING },
            locationName: { type: Type.STRING },
            duration: { type: Type.NUMBER },
            coordinates: {
              type: Type.OBJECT,
              properties: {
                lat: { type: Type.NUMBER },
                lng: { type: Type.NUMBER }
              }
            }
          }
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");
    return JSON.parse(text);
  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    throw error;
  }
};

export const askTravelAssistant = async (question: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: modelId,
      contents: `你是一位 2025 年 12 月倫敦團體旅遊的熱心旅遊助理。請用繁體中文簡潔地回答這個問題：${question}`,
    });
    return response.text || "我目前無法找到答案。";
  } catch (error) {
    return "抱歉，我目前無法連接到旅遊資料庫。";
  }
};